<?php
include_once('./QRcode.php');

// 接收参数
$content = $_GET['c'] ? $_GET['c'] : 'https://www.zxki.cn/';
$size = $_GET['s'] ? $_GET['s'] : 7;
$background = $_GET['bc']?explode(',',$_GET['bc']):array(255, 255, 255, 0);
$foreground = $_GET['fc']?explode(',',$_GET['fc']):array(0, 0, 0, 0);

// 图片输出
header("Content-type: image/jpg");
echo Toplib_Lib_QRcode::png($content,false,QR_ECLEVEL_L,$size,1,false,$background,$foreground);
